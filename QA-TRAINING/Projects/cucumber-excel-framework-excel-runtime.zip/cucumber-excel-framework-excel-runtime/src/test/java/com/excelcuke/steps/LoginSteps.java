package com.excelcuke.steps;

import com.excelcuke.util.Config;
import com.excelcuke.util.DriverFactory;
import com.excelcuke.util.ScenarioContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import static org.testng.Assert.assertTrue;

public class LoginSteps {

    private WebDriver driver() {
        return DriverFactory.getDriver();
    }

    @Given("I open base url")
    public void i_open_base_url() {
        driver().get(Config.get("baseUrl", "https://www.saucedemo.com/"));
    }

    @When("I login with test data")
    public void i_login_with_test_data() {
        String username = ScenarioContext.val("username");
        String password = ScenarioContext.val("password");
        driver().findElement(By.id("user-name")).clear();
        driver().findElement(By.id("user-name")).sendKeys(username);
        driver().findElement(By.id("password")).clear();
        driver().findElement(By.id("password")).sendKeys(password);
        driver().findElement(By.id("login-button")).click();
    }

    @Then("I should see data {string}")
    public void i_should_see_data(String field) {
        String expected = String.valueOf(ScenarioContext.val(field));
        WebDriverWait wait = new WebDriverWait(driver(), Duration.ofSeconds(5));
        if ("success".equalsIgnoreCase(expected)) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container")));
            assertTrue(driver().getCurrentUrl().contains("inventory"), "Expected to land on products page");
        } else {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
            String page = driver().getPageSource().toLowerCase();
            assertTrue(page.contains("epic sadface") || page.contains("do not match"),
                    "Expected an error message on failed login");
        }
    }
}
