package com.excelcuke.util;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.time.Duration;

public class DriverFactory {
    private static final ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

    public static void initDriver() {
        if (tlDriver.get() == null) {
            String browser = Config.get("browser", "chrome").toLowerCase();
            boolean headless = Config.getBool("headless", false);

            if (!"chrome".equals(browser)) {
                System.err.println("[DriverFactory] Only 'chrome' implemented in this starter. Using chrome.");
            }

            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            if (headless) options.addArguments("--headless=new");
            WebDriver driver = new ChromeDriver(options);
            int iw = Config.getInt("implicitWaitSec", 0);
            if (iw > 0) driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(iw));
            tlDriver.set(driver);
        }
    }

    public static WebDriver getDriver() {
        return tlDriver.get();
    }

    public static void quitDriver() {
        if (tlDriver.get() != null) {
            tlDriver.get().quit();
            tlDriver.remove();
        }
    }
}
