package com.excelcuke.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BookTicketsSteps {


    @Given("I have bookmyshow app")
    public void i_have_bookmyshow_app() {
      System.out.println("");
    }
    @Given("I search for the movie")
    public void i_search_for_the_movie() {

    }
    @When("select the theater")
    public void select_the_theater() {

    }
    @When("I will complete the payment")
    public void i_will_complete_the_payment() {

    }
    @Then("I validate i recived my ticket")
    public void i_validate_i_recived_my_ticket() {

    }

}
