package com.excelcuke.hooks;

import com.excelcuke.util.DriverFactory;
import com.excelcuke.util.ScenarioContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
    @Before(order = 0)
    public void setUp() {
        DriverFactory.initDriver();
    }

    @After(order = 1)
    public void tearDown() {
        DriverFactory.quitDriver();
        ScenarioContext.clear();
    }
}
