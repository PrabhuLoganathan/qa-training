package com.excelcuke.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class ExcelReader {

    public static List<Map<String, String>> readSheet(Path excelPath, String sheetName) {
        List<Map<String, String>> rows = new ArrayList<>();
        if (!Files.exists(excelPath)) {
            throw new RuntimeException("Excel not found: " + excelPath.toAbsolutePath());
        }
        try (FileInputStream fis = new FileInputStream(excelPath.toFile());
             Workbook wb = new XSSFWorkbook(fis)) {

            Sheet sheet = wb.getSheet(sheetName);
            if (sheet == null) throw new RuntimeException("No sheet named: " + sheetName);

            Row header = sheet.getRow(0);
            if (header == null) throw new RuntimeException("Missing header row in sheet: " + sheetName);

            List<String> columns = new ArrayList<>();
            for (Cell c : header) columns.add(c.getStringCellValue().trim());

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;
                Map<String,String> map = new LinkedHashMap<>();
                for (int c = 0; c < columns.size(); c++) {
                    Cell cell = row.getCell(c);
                    map.put(columns.get(c), getCellValueAsString(cell));
                }
                rows.add(map);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed reading excel: " + e.getMessage(), e);
        }
        return rows;
    }

    public static Map<String,String> findRowBy(List<Map<String,String>> rows, String column, String value) {
        for (Map<String,String> row : rows) {
            String v = row.getOrDefault(column, "");
            if (v != null && v.trim().equalsIgnoreCase(value.trim())) {
                return row;
            }
        }
        return null;
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue().toString()
                    : String.valueOf((long)cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> cell.getCellFormula();
            case BLANK, _NONE, ERROR -> "";
        };
    }
}
