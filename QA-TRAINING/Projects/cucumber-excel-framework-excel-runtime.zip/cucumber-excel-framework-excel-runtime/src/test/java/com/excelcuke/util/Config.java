package com.excelcuke.util;

import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;

public class Config {
    private static final Properties P = new Properties();

    static {
        try (InputStream is = Config.class.getClassLoader().getResourceAsStream("config/config.properties")) {
            if (is != null) {
                P.load(is);
            } else {
                System.err.println("[Config] WARNING: config/config.properties not found on classpath.");
            }
            // Allow overrides via -Dconf.key=value
            for (String name : System.getProperties().stringPropertyNames()) {
                if (name.startsWith("conf.")) {
                    String key = name.substring("conf.".length());
                    P.setProperty(key, System.getProperty(name));
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config.properties", e);
        }
    }

    public static String get(String key, String def) {
        return P.getProperty(key, def);
    }

    public static String get(String key) {
        return P.getProperty(key);
    }

    public static int getInt(String key, int def) {
        try {
            return Integer.parseInt(P.getProperty(key));
        } catch (Exception e) {
            return def;
        }
    }

    public static boolean getBool(String key, boolean def) {
        String v = P.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }
}
