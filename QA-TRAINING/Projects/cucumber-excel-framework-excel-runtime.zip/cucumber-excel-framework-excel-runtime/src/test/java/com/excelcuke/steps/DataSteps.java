package com.excelcuke.steps;

import com.excelcuke.util.Config;
import com.excelcuke.util.ExcelReader;
import com.excelcuke.util.ScenarioContext;
import io.cucumber.java.en.Given;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

public class DataSteps {

    @Given("I load test data for {string} from {string} sheet {string}")
    public void i_load_test_data_for_from_sheet(String scenarioName, String excelRelativePath, String sheetName) {
        // Resolve excel path: relative to resources root
        String base = System.getProperty("user.dir");
        Path excel = Path.of(base, "src", "test", "resources", excelRelativePath);
        List<Map<String, String>> rows = ExcelReader.readSheet(excel, sheetName);

        Map<String, String> row = ExcelReader.findRowBy(rows, "ScenarioName", scenarioName);
        if (row == null) {
            throw new RuntimeException("No Excel row found where ScenarioName = '" + scenarioName + "' in sheet '" + sheetName + "'");
        }
        ScenarioContext.setData(row);
    }

}
