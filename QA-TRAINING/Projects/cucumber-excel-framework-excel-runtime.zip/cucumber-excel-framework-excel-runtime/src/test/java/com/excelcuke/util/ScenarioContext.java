package com.excelcuke.util;

import java.util.Map;

public class ScenarioContext {
    private static final ThreadLocal<Map<String,String>> DATA = new ThreadLocal<>();

    public static void setData(Map<String,String> row) {
        DATA.set(row);
    }

    public static Map<String,String> getData() {
        return DATA.get();
    }

    public static String val(String key) {
        Map<String,String> map = DATA.get();
        return map == null ? null : map.get(key);
    }

    public static void clear() {
        DATA.remove();
    }
}
