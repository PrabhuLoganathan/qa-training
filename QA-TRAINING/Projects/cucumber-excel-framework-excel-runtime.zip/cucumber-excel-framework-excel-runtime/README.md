# Cucumber + Selenium + Excel at runtime (Scenario Outline selects row)

This framework lets you choose *which* Excel row to run **from the Scenario Outline Examples**.
At runtime, a step loads the Excel row by `ScenarioName` and stores it in a thread-local context for use by subsequent steps.

## Flow
1. `Scenario Outline` includes a `ScenarioName` column in Examples.
2. Step `I load test data for "<ScenarioName>" from "data/LoginData.xlsx" sheet "Login"`
   finds the matching row (`ScenarioName` column) and stores the row in `ScenarioContext`.
3. Steps use that data (e.g., `I login with test data`, `I should see data "expectedResult"`).

## Run
```bash
mvn clean test
```

## Override properties
```bash
mvn -Dconf.baseUrl="https://www.saucedemo.com/" -Dconf.headless=true -Dconf.implicitWaitSec=8 test
```

## Excel format (LoginData.xlsx)
Headers (row 1): `Enabled, ScenarioName, username, password, expectedResult`

## Extend for your app
- Add more columns in Excel (e.g., `accountNumber`, `pin`, etc.).
- Access them in steps via `ScenarioContext.val("<columnName>")` or create new steps like
  `When I fill "<field>" with data "<columnName>"`.
