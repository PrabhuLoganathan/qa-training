package P_Locators;

public class LoginLocators {

	
	
	public static String userName_ID="user";
	public static String password_xpath="//*[@id='pass']";
	public static String login_css="#right_col_top > form > div > input";
	
	
}
