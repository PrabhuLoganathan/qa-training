package FrameWork_PageObject;

public class HomePage {

}
