package FrameWork_PageObject;

public class EmailPage {
	
	public void enterEmail(){
		System.out.println(" Emailed");
	}

}
