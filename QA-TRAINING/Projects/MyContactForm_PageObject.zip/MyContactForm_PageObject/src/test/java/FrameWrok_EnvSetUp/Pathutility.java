package FrameWrok_EnvSetUp;

public class Pathutility {

	public static final String DRIVER_PATH = "/Users/jarvis/Downloads/chromedriver";
	public static final String IEDRIVER_PATH = null;


}
