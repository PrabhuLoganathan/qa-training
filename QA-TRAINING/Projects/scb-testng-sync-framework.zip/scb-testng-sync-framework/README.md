# SCB TestNG Sync Framework

A minimal, production-style Selenium + TestNG framework targeting **https://www.sc.com/en/** that demonstrates:

- Synchronization: `Thread.sleep`, **Implicit Wait**, **Explicit Wait** (WebDriverWait + ExpectedConditions)
- Handling AJAX / dynamic content via robust conditions
- Cookie banner handling (OneTrust)
- Verification techniques (element properties, titles, text, clickability, links)
- Assertions (hard & soft patterns), with examples
- TestNG parallelism, listeners with screenshots on failure
- Hands-on assignments at the end

## Quick Start

```bash
# 1) Build
mvn -q -e -DskipTests package

# 2) Run tests (Chrome by default)
mvn -q -Dselenium.browser=chrome test

# 3) To run in Firefox
mvn -q -Dselenium.browser=firefox test
```

WebDriver binaries are auto-managed by **WebDriverManager**.

## Project Layout

```
src/
 ├─ main/java/com/scbank
 │   ├─ core
 │   │   ├─ DriverFactory.java
 │   │   ├─ Waits.java
 │   │   └─ AssertionsUtil.java
 │   ├─ listeners
 │   │   └─ TestListener.java
 │   └─ pages
 │       └─ HomePage.java
 └─ test/java/com/scbank/tests
     └─ HomePageTests.java
testng.xml
pom.xml
```

## Notes

- The cookie banner is handled via the typical OneTrust selector `#onetrust-accept-btn-handler`. If the site changes this ID, update `HomePage.acceptCookiesIfPresent()`.
- Implicit wait is set via TestNG parameter (`implicitWaitSec`). Explicit waits are used for all critical interactions.
- `Waits` includes ready-to-use utilities for AJAX-heavy pages.
- On failure, a screenshot is saved in `./target/screenshots` and attached to the TestNG report.

## Hands-on Assignments

1. Add a test that verifies **search** (if present) opens and returns results (use explicit waits).
2. Add a test that validates all top navigation **links are clickable** and return **HTTP 200** (hint: use `HttpURLConnection`).
3. Replace any `Thread.sleep` with a **fluent wait** that waits for either visibility or clickability.
4. Add **SoftAssert** flow to collect multiple verifications before asserting.
5. Implement a **retry** analyzer for flaky AJAX components.
6. Extend `HomePage` with methods to verify specific hero banners/cards are visible.
7. Add a **PageFactory** variant for the HomePage (optional) and compare readability.
