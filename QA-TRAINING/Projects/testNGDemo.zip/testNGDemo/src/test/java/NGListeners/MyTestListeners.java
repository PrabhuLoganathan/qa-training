package NGListeners;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class MyTestListeners implements ITestListener {

	public void onTestStart(ITestResult result) {

		System.out.println(result.getName() + "  Test Case Started ---------------");

	}

	public void onTestSuccess(ITestResult result) {

		System.out.println(result.getName() + "  Test Case Passed ---------------");

	}

	public void onTestFailure(ITestResult result) {

		System.out.println(result.getName() + "  Test Case failed ---------------");

	}

	public void onTestSkipped(ITestResult result) {

		System.out.println(result.getName() + "  Test Case Skipped ---------------");

	}

}
