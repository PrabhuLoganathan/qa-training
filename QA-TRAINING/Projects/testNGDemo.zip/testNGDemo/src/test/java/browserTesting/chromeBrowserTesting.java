package browserTesting;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BasaClass;

@Listeners(NGListeners.MyTestListeners.class)
public class chromeBrowserTesting  extends BasaClass{




	@Test(priority = 2, invocationCount = 4,description = "We are doing valid login")
	public void testCase() {

		driver.get("https://www.mycontactform.com");

		System.out.println(driver.getTitle());

		List<WebElement> loginElements = driver.findElements(By.tagName("input"));

		loginElements.get(0).sendKeys("Prabhu123");

		loginElements.get(1).sendKeys("12345");

		loginElements.get(2).click();

		System.out.println(driver.getTitle());

	}

	@Test(priority = 1, description = " This is tesing the invlaid login")
	public void testCase_Invalid() {

		driver.get("https://www.mycontactform.com");

		System.out.println(driver.getTitle());

		List<WebElement> loginElements = driver.findElements(By.tagName("input"));

		loginElements.get(0).sendKeys("yiuyiu");

		loginElements.get(1).sendKeys("12345");

		loginElements.get(2).click();

		System.out.println(driver.getTitle());

	}

}
