package browserTesting;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BasaClass;

public class TestHardAsserts  extends BasaClass{

	



	@Test(priority = 2,description = "We are doing valid login")
	public void testCase() {

		driver.get("https://www.mycontactform.com");

		System.out.println(driver.getTitle());
	
		Assert.assertEquals(driver.getTitle(), "Free Contact and Email Forms - myContactForm.com");

		List<WebElement> loginElements = driver.findElements(By.tagName("input"));

		loginElements.get(0).sendKeys("Prabhu123");

		loginElements.get(1).sendKeys("12345");

		loginElements.get(2).click();

		System.out.println(driver.getTitle());
		
		Assert.assertEquals(driver.getTitle(),"Form Magement - myContactForm.com" );

	}



}
