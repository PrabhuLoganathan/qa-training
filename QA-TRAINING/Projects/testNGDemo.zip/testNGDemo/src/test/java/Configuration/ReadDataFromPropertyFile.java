package Configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromPropertyFile {
	Properties prop;;
	
	public ReadDataFromPropertyFile() {
		// TODO Auto-generated constructor stub
		try {
			FileInputStream fis = new FileInputStream(new File("./src/test/resources/config/config.properties"));
			
			prop = new Properties();
			
			
			prop.load(fis);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	System.out.println(	prop.getProperty("Username"));
		
	}

	public  String getDataFormConfigFile(String key) {

		return prop.getProperty(key);
		
	}

	

}
