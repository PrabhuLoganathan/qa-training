package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Configuration.ReadDataFromPropertyFile;

public class LoginPage {
	
	
	@FindBy(id ="user")
	WebElement  usernmameElement;
	
	@FindBy(id ="pass")
	WebElement  passwordElement;
	
	
	@FindBy(name ="btnSubmit")
	WebElement  loginButtonElement;
	
	
	public WebElement getUsernameElement() {
		return usernmameElement;
		
	}
	
	
	public WebElement getPasswordElement() {
		return passwordElement;
		
	}
	
	public WebElement getloginButton() {
		return loginButtonElement;
		
	}
	
	
	public void doValidLogin() {
		
		usernmameElement.sendKeys(new  ReadDataFromPropertyFile().getDataFormConfigFile("Username"));
		passwordElement.sendKeys("12345");
		
		loginButtonElement.click();
		
	}
	
public void doInvValidLogin() {
		
		usernmameElement.sendKeys("Prabhu123");
		passwordElement.sendKeys("33");
		
		loginButtonElement.click();
		
	}
	

}
