package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;


public class Ps_steps {
	WebDriver driver;

	@Given("I want open {string} browser")
	public void i_want_open_browser(String browserName) {

		// System.setProperty("", "");

		// WebDriverManager.chromedriver().setup();

		switch (browserName) {
		case "chrome":
			driver = new ChromeDriver();
			break;

		default:
			break;
		}

	}

	@Given("as user wants to launch {string} Url")
	public void as_user_wants_to_launch_url(String urlInput) {

		driver.get(urlInput);

	}

	@Then("I validate that title should be {string}")
	public void i_validate_that_title_should_be(String titleToValidate) {

		driver.getTitle();

	}

}
