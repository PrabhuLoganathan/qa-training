package DemoPage;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class DemoPageAutomationTest {
    private WebDriver driver;
    private WebDriverWait wait;
    private Actions actions;

    @BeforeClass
    public void setup() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        actions = new Actions(driver);
    }

    @AfterClass(alwaysRun = true)
    public void teardown() {
        if (driver != null) driver.quit();
    }

    @Test
    public void automateAllElements() {
        driver.get("https://seleniumbase.io/demo_page");

        // ---- Headings present
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h1")));
         WebElement h3 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h3")));
        Assert.assertTrue(h3.getText().toLowerCase().contains("automation practice"));
        
   
        
        // ---- Hover dropdown -> click "Link Two"
        WebElement hoverMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(.,'Hover Dropdown')][self::div or self::span or self::a or self::button]")));
        actions.moveToElement(hoverMenu).pause(Duration.ofMillis(300)).perform();
        clickIfPresent(By.xpath("//a[contains(.,'Link Two')]|//div[contains(@class,'dropdown')]//a[contains(.,'Link Two')]"));

        // ---- Text input (id known from docs: #myTextInput)  :contentReference[oaicite:1]{index=1}
        WebElement textInput = firstPresent(
                By.cssSelector("#myTextInput"),
                By.cssSelector("input[type='text']"));
        textInput.clear();
        textInput.sendKeys("SeleniumBase Demo — automated");

        // ---- Textarea (docs show #myTextarea)  :contentReference[oaicite:2]{index=2}
        WebElement textarea = firstPresent(
                By.cssSelector("#myTextarea"),
                By.cssSelector("textarea"));
        textarea.clear();
        textarea.sendKeys("Filling the textarea ✅");

        // ---- Pre-filled & placeholder fields (verify + type/append)
        WebElement prefilled = firstPresent(
                By.cssSelector("input[value][type='text']"),
                By.xpath("//input[@type='text' and string-length(@value)>0]"));
        if (prefilled != null) {
            prefilled.sendKeys(" + appended");
        }
        WebElement placeholder = firstPresent(
                By.cssSelector("input[placeholder]"),
                By.xpath("//input[@placeholder]"));
        if (placeholder != null) {
            placeholder.clear();
            placeholder.sendKeys("Typing into placeholder");
        }

        // ---- Read-only text field (just assert readonly)
        WebElement readonly = firstPresent(
                By.cssSelector("input[readonly]"),
                By.xpath("//input[@readonly]"));
        if (readonly != null) {
            Assert.assertTrue(Boolean.parseBoolean(readonly.getAttribute("readonly")) || readonly.getAttribute("readonly") != null,
                    "Expected read-only field.");
        }

        // ---- Button (docs: #myButton toggles #pText color/text)  :contentReference[oaicite:3]{index=3}
        WebElement pText = firstPresent(By.cssSelector("#pText"), By.xpath("//p[contains(.,'This Text')]"));
        String before = (pText != null) ? pText.getText() : "";
        WebElement button = firstPresent(By.cssSelector("#myButton"), By.xpath("//button[contains(.,'Click Me')]"));
        if (button != null) {
            button.click();
            if (pText != null) {
                wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(pText, before)));
            }
        }

        // ---- SVG (click/highlight rect if present)
        WebElement svgRect = firstPresent(
                By.cssSelector("svg rect"),
                By.xpath("//*[name()='svg']/*[name()='rect']"));
        if (svgRect != null) {
            js("arguments[0].setAttribute('stroke','black'); arguments[0].setAttribute('stroke-width','3');", svgRect);
        }

        // ---- Slider / progress / meter
        WebElement slider = firstPresent(By.cssSelector("input[type='range']"));
        if (slider != null) {
            setRangeSliderValue(slider, 75); // set to 75 via JS to be reliable
        }
        WebElement progress = firstPresent(By.cssSelector("progress[value]"));
        if (progress != null) {
            String val = progress.getAttribute("value");
            // no hard assert; just log/verify it looks numeric
            Assert.assertTrue(val.matches("\\d+"), "Progress value should be numeric");
        }
        WebElement meter = firstPresent(By.cssSelector("meter[value]"));
        if (meter != null) {
            String mval = meter.getAttribute("value");
            Assert.assertTrue(mval.matches("\\d+(\\.\\d+)?"), "Meter value should be numeric");
        }

        // ---- Select dropdown (try selecting each "Set to XX%" option)
        WebElement selectEl = firstPresent(By.cssSelector("select"), By.xpath("//select"));
        if (selectEl != null) {
            Select select = new Select(selectEl);
            for (String option : new String[]{"Set to 25%", "Set to 50%", "Set to 75%", "Set to 100%"}) {
                try { select.selectByVisibleText(option); } catch (Exception ignored) {}
            }
        }

        // ---- iFrame: image & checkbox inside
        List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
        if (!iframes.isEmpty()) {
            driver.switchTo().frame(iframes.get(0));
            // Try to tick any checkbox inside iframe
            WebElement iframeCheckbox = firstPresent(By.cssSelector("input[type='checkbox']"));
            if (iframeCheckbox != null && !iframeCheckbox.isSelected()) iframeCheckbox.click();
            // Assert image exists
            WebElement img = firstPresent(By.cssSelector("img"), By.xpath("//img"));
            Assert.assertNotNull(img, "Expected an image in iframe");
            driver.switchTo().defaultContent();

        }

        // ---- Radios
        clickIfPresent(By.cssSelector("input[type='radio']"));
        clickIfPresent(By.xpath("(//input[@type='radio'])[last()]"));

        // ---- Checkboxes outside iframe (including any “pre-check”)
        for (WebElement cb : driver.findElements(By.cssSelector("input[type='checkbox']"))) {
            if (cb.isDisplayed() && cb.isEnabled()) {
                cb.click(); // toggle
            }
        }

        // ---- Drag & Drop A -> B (or between two drop zones)
        WebElement dragA = findByTextContains("Drag and Drop A");
        WebElement dropB = findByTextContains("Drag and Drop B");
        if (dragA != null && dropB != null) {
            try {
                actions.dragAndDrop(dragA, dropB).perform();
            } catch (Exception e) {
                // JS fallback
//                jsHtml5DragAndDrop(dragA, dropB);
            }
        
        }

        // ---- Links: open SeleniumBase GitHub (new tab), validate, return
        String original = driver.getWindowHandle();
        clickIfPresent(By.partialLinkText("GitHub"));
        switchToNewTab(original);
        if (driver.getWindowHandles().size() > 1) {
            // Title should contain "GitHub" typically
            Assert.assertTrue(driver.getTitle().toLowerCase().contains("github"));
            driver.close();
            driver.switchTo().window(original);
        }

        // ---- Footer docs link sanity click
        clickIfPresent(By.partialLinkText("SeleniumBase Demo Page"));
        // (docs show this link exists; test remains on same site) :contentReference[oaicite:4]{index=4}
    }

    // ---------- helpers ----------
    private WebElement firstPresent(By... locators) {
        for (By by : locators) {
            try {
                WebElement e = driver.findElement(by);
                if (e != null) return e;
            } catch (NoSuchElementException ignored) {}
        }
        return null;
    }

    private void clickIfPresent(By by) {
        try {
            WebElement e = wait.until(ExpectedConditions.elementToBeClickable(by));
            e.click();
        } catch (Exception ignored) {}
    }

    private WebElement findByTextContains(String text) {
        try {
            return driver.findElement(By.xpath("//*[contains(normalize-space(.), '" + text + "')]"));
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    private void setRangeSliderValue(WebElement slider, int value0to100) {
        js("arguments[0].value=arguments[1]; arguments[0].dispatchEvent(new Event('input', {bubbles:true}));", slider, value0to100);
    }



    private Object js(String script, Object... args) {
        return ((JavascriptExecutor) driver).executeScript(script, args);
    }

    private void switchToNewTab(String originalHandle) {
        for (String h : driver.getWindowHandles()) {
            if (!h.equals(originalHandle)) {
                driver.switchTo().window(h);
                return;
            }
        }
    }
}
