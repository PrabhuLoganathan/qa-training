package tests;

import base.BaseTest;
import org.openqa.selenium.*;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class RelativeLocatorsTests extends BaseTest {

    @Test
    public void relativeLocators_onLoginForm() {
        new LoginPage(driver).open();
        WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(RelativeLocator.with(By.tagName("input")).below(username));
        WebElement submit   = driver.findElement(RelativeLocator.with(By.tagName("button")).near(password));
        username.sendKeys("student");
        password.sendKeys("Password123");
        submit.click();
        Assert.assertTrue(driver.getCurrentUrl().contains("logged-in-successfully"));
    }
}
