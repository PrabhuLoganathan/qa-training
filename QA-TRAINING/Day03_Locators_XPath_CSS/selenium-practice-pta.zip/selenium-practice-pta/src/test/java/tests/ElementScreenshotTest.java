package tests;

import base.BaseTest;
import org.openqa.selenium.*;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

public class ElementScreenshotTest extends BaseTest {
    @Test
    public void element_screenshot_onError() throws Exception {
        LoginPage page = new LoginPage(driver).open()
                .typeUsername("wrongUser")
                .typePassword("WrongPass");
        page.submit();
        WebElement error = driver.findElement(By.id("error"));
        File src = error.getScreenshotAs(OutputType.FILE);
        Path out = Path.of("target", "screenshots", "error.png");
        Files.createDirectories(out.getParent());
        Files.copy(src.toPath(), out);
        Assert.assertTrue(Files.exists(out));
    }
}
