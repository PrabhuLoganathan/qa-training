package tests;

import base.BaseTest;
import org.openqa.selenium.WindowType;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import java.util.Set;

public class NewWindowAndTabTests extends BaseTest {
    @Test
    public void openNewTab_andNavigate() {
        new LoginPage(driver).open();
        String firstHandle = driver.getWindowHandle();
        driver.switchTo().newWindow(WindowType.TAB);
        driver.get(LoginPage.URL);
        Set<String> handles = driver.getWindowHandles();
        Assert.assertEquals(handles.size(), 2);
        driver.switchTo().window(firstHandle);
        Assert.assertTrue(driver.getCurrentUrl().contains("practicetestautomation.com"));
    }
}
