package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoggedInPage;
import pages.LoginPage;

public class LoginTests extends BaseTest {

    @DataProvider(name = "validCreds")
    public Object[][] validCreds() {
        return new Object[][]{{"student", "Password123"}};
    }

    @DataProvider(name = "invalidCreds")
    public Object[][] invalidCreds() {
        return new Object[][]{
                {"wrongUser", "Password123", "Your username is invalid!"},
                {"student", "WrongPass", "Your password is invalid!"},
                {"", "", "Your username is invalid!"}
        };
    }

    @Test(dataProvider = "validCreds")
    public void login_shouldSucceed(String user, String pass) {
        LoginPage login = new LoginPage(driver).open()
                .typeUsername(user)
                .typePassword(pass);
        login.submit();

        LoggedInPage loggedIn = new LoggedInPage(driver);
        Assert.assertTrue(loggedIn.getHeading().toLowerCase().contains("logged in"));
        Assert.assertTrue(loggedIn.currentUrl().contains("logged-in-successfully"));
    }

    @Test(dataProvider = "invalidCreds")
    public void login_shouldFail(String user, String pass, String expectedMsg) {
        LoginPage login = new LoginPage(driver).open()
                .typeUsername(user)
                .typePassword(pass);
        login.submit();
        String actual = login.getErrorText();
        Assert.assertTrue(actual.toLowerCase().contains(expectedMsg.toLowerCase()));
    }
}
