package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

public class LoggedInPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By heading = By.tagName("h1");

    public LoggedInPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public String getHeading() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(heading)).getText();
    }

    public String currentUrl() {
        return driver.getCurrentUrl();
    }
}
