package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class LoginPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By username = By.id("username");
    private final By password = By.id("password");
    private final By submit   = By.id("submit");
    private final By error    = By.id("error");

    public static final String URL = "https://practicetestautomation.com/practice-test-login/";

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public LoginPage open() {
        driver.get(URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(username));
        return this;
    }

    public LoginPage typeUsername(String value) {
        driver.findElement(username).clear();
        driver.findElement(username).sendKeys(value);
        return this;
    }

    public LoginPage typePassword(String value) {
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(value);
        return this;
    }

    public void submit() {
        driver.findElement(submit).click();
    }

    public String getErrorText() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(error)).getText();
        } catch (TimeoutException e) {
            return "";
        }
    }
}
